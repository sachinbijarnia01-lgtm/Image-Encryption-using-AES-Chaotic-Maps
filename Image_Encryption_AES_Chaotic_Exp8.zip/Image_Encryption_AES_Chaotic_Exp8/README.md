# Image Encryption using AES-256 & Chaotic Maps
**Experiment 8 – Secure Storage, Transmission & Digital Signature**

A complete, working cryptography & image security mini-project featuring:
1. **AES-256 Image Encryption Engine** (`GCM`, `CBC`, `CTR`, and `ECB` for structural contour-leakage comparison) with PBKDF2-HMAC-SHA256 key derivation.
2. **Chaotic-Map Image Encryption Engine** combining **2D Generalized Arnold Cat Map** spatial confusion, **1D Logistic Map** global pixel permutation, and **2-Round Bidirectional ARX Diffusion** driven by a **Logistic-Sine Coupled Map (LSCM)** keystream ($10^{-14}$ key sensitivity).
3. **Statistical & Differential Cryptanalysis Suite**:
   - **Histogram Uniformity Analysis** (256-bin R, G, B & Luminance histograms + $\chi^2$ goodness-of-fit test)
   - **Adjacent Pixel Correlation Analysis** (Horizontal $r_H$, Vertical $r_V$, Diagonal $r_D$ + scatter plots)
   - **Information Entropy Analysis** (Global & per-channel Shannon Entropy $H(m)$ vs. ideal $8.0$ bits/byte)
   - **Differential Attack Metrics** (**NPCR** & **UACI** for 1-LSB plaintext perturbation) and **MSE / PSNR** lossless verification
4. **Exp 8 – Secure Storage, Transmission & Digital Signature Protocol**:
   - **RSA-2048-PSS (SHA-256)** Digital Signatures for authenticity, integrity, and non-repudiation
   - **RSA-2048-OAEP (SHA-256)** Asymmetric Key Encapsulation for session keys / chaotic seeds
   - **Secure Storage Vault** (`vault/*.secimg.json`) + Active Tampering, Signature Forgery & $10^{-14}$ Key-Sensitivity Simulations
5. **Interactive Web Lab Workbench (`app.py`)** + **Automated CLI Report Generator (`run_experiment.py`)** + **Unit Test Suite (`tests/test_project.py`)**.

---

## Project Structure

```text
.
├── app.py                      # Interactive Flask Web Workbench (0.0.0.0:5000)
├── run_experiment.py           # CLI benchmark runner & high-res Matplotlib plot generator
├── requirements.txt            # Python package dependencies
├── src/
│   ├── aes_cipher.py           # AES-256 (GCM, CBC, CTR, ECB) image encrypt/decrypt
│   ├── chaotic_cipher.py       # 2D Arnold Cat Map + Logistic + LSCM-ARX chaotic cipher
│   ├── metrics.py              # Histogram, Chi-Square, Correlation, Entropy, NPCR, UACI
│   ├── exp8_protocol.py        # RSA-2048-PSS signatures, RSA-OAEP wrap, Vault & Channel sim
│   ├── comparison_pipeline.py  # Unified side-by-side comparison pipeline
│   └── sample_images.py        # Synthetic test images (Landscape, Emblem, MRI, Fractal)
├── templates/
│   └── index.html              # Interactive Web UI with live HTML5 Canvas charts
├── samples/                    # Generated 256x256 RGB test images
├── outputs/                    # Generated lab figures & metrics_report.json
├── vault/                      # Persisted signed secure envelopes (*.secimg.json)
└── tests/
    └── test_project.py         # Automated unit & integration tests
```

---

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Automated CLI Experiment & Generate Lab Figures
```bash
python3 run_experiment.py
```
Generates publication-ready figures in `outputs/`:
- `outputs/visual_comparison.png` — Side-by-side Original, AES-ECB (leaking contours), AES-CBC, AES-GCM, Chaotic Cipher, and Lossless Decrypted images
- `outputs/histogram_analysis.png` — R, G, B histograms & $\chi^2$ uniformity scores
- `outputs/correlation_analysis.png` — 3×3 Horizontal, Vertical, Diagonal correlation scatter plots
- `outputs/exp8_security_demo.png` — Signed transmission & $\Delta x_0 = 10^{-14}$ chaotic key sensitivity demo
- `outputs/metrics_report.json` — Structured experimental metrics summary

### 3. Launch Interactive Web Application
```bash
python3 app.py
```
Open the live server at `http://localhost:5000` (or the live preview panel) to upload custom images, tune AES modes and chaotic parameters ($x_0, r$, Arnold iterations), inspect interactive histograms & scatter plots, and simulate active tampering attacks.

### 4. Run Unit & Integration Tests
```bash
python3 -m unittest discover -s tests -v
```

---

## Mathematical Formulation

### 1. Chaotic Confusion–Diffusion Scheme
1. **2D Generalized Arnold Cat Map (Spatial Confusion)**:
   $$\begin{bmatrix} x' \\ y' \end{bmatrix} = \begin{bmatrix} 1 & p \\ q & pq + 1 \end{bmatrix} \begin{bmatrix} x \\ y \end{bmatrix} \bmod N, \qquad \det = 1$$
2. **1D Logistic Map Global Scrambling**:
   $$x_{n+1} = r \cdot x_n (1 - x_n), \quad r \in (3.985, 4.0), \; x_0 \in (0, 1)$$
3. **Logistic–Sine Coupled Map (LSCM) & Bidirectional ARX Diffusion**:
   $$y_{n+1} = \sin\!\Big(\pi \big(4\theta y_n(1 - y_n) + (1 - \theta)\sin(\pi y_n)\big)\Big)$$
   Combines incompatible algebraic groups—bitwise XOR ($\oplus$) and modular addition ($\boxplus \bmod 256$)—in forward and reverse passes so a 1-bit change in *any* pixel cascades across $>99.6\%$ of the cipher image.

### 2. Evaluation Metrics
- **Shannon Entropy**: $H(m) = -\sum_{i=0}^{255} P(m_i)\log_2 P(m_i)$ (Ideal $= 8.0000$ bits/byte)
- **Adjacent Pixel Correlation**: $r_{xy} = \frac{\text{Cov}(x, y)}{\sqrt{D(x)D(y)}}$ (Ideal $\approx 0.0000$)
- **Histogram Uniformity ($\chi^2$)**: $\chi^2 = \sum_{i=0}^{255} \frac{(O_i - E)^2}{E}$ ($\chi^2_{0.05, 255} = 293.25$)
- **NPCR & UACI**: Ideal $\text{NPCR} = 99.6094\%$, Ideal $\text{UACI} = 33.4635\%$

---

## Experimental Results Summary (`256×256` RGB Natural Scene)

| Metric | Ideal Target | Original Image | AES-256-CBC | AES-256-GCM | Chaotic Map (Arnold+LSCM) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Shannon Entropy (bits/byte)** | `8.00000` | `7.52932` | `7.99914` | `7.99920` | `7.99910` |
| **Histogram $\chi^2$ ($df=255$)** | `< 293.25` | `175,310.3` | `234.5` (Pass) | `217.0` (Pass) | `244.4` (Pass) |
| **Horizontal Correlation ($r_H$)** | `0.00000` | `+0.99509` | `-0.00065` | `-0.00011` | `+0.00024` |
| **Vertical Correlation ($r_V$)** | `0.00000` | `+0.98942` | `+0.00307` | `+0.00163` | `+0.00060` |
| **Diagonal Correlation ($r_D$)** | `0.00000` | `+0.98923` | `+0.00008` | `-0.00437` | `-0.00375` |
| **NPCR (1-LSB Plaintext Diff)** | `99.6094%` | — | `99.6068%` | `0.0005%`* | `99.5661%` |
| **UACI (1-LSB Plaintext Diff)** | `33.4635%` | — | `33.3836%` | `0.0000%`* | `33.4357%` |
| **Decryption MSE (Lossless)** | `0.0` | `0.0` | `0.0` | `0.0` | `0.0` |

*\*Note: Under a fixed/reused nonce, stream modes (`GCM`/`CTR`) XOR plaintext with an identical keystream, illustrating why fresh random nonces are mandatory in AES-GCM/CTR, whereas chained/bidirectional schemes (`AES-CBC` and `Chaotic ARX`) diffuse a single pixel change across ~99.6% of all pixels.*
