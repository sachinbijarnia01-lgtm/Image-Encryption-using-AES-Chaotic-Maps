"""Interactive Flask Web Workbench for Experiment 8:
Image Encryption using AES-256 & Chaotic Maps + Secure Storage, Transmission & Digital Signature.
"""

from __future__ import annotations

import base64
import io
import json
from pathlib import Path
from flask import Flask, jsonify, render_template, request, send_from_directory
import numpy as np
from PIL import Image

from src.chaotic_cipher import ChaoticParams
from src.comparison_pipeline import array_to_data_uri, run_full_comparison
from src.exp8_protocol import simulate_exp8_transmission
from src.sample_images import ensure_sample_images

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024  # 12 MB upload limit

SAMPLES_MAP = ensure_sample_images("samples")
VAULT_DIR = Path("vault")
VAULT_DIR.mkdir(parents=True, exist_ok=True)


def _load_target_image(payload: dict, max_dim: int = 320) -> np.ndarray:
    """Load either a user-uploaded base64 image or one of the built-in test images."""
    custom_b64 = payload.get("custom_image_b64")
    if custom_b64:
        if "," in custom_b64:
            custom_b64 = custom_b64.split(",", 1)[1]
        raw = base64.b64decode(custom_b64)
        img = Image.open(io.BytesIO(raw)).convert("RGB")
        if max(img.size) > max_dim:
            img.thumbnail((max_dim, max_dim), Image.Resampling.LANCZOS)
        return np.asarray(img, dtype=np.uint8)

    sample_key = payload.get("sample", "natural_scene")
    if sample_key not in SAMPLES_MAP:
        sample_key = "natural_scene"
    img = Image.open(SAMPLES_MAP[sample_key]).convert("RGB")
    return np.asarray(img, dtype=np.uint8)


@app.after_request
def add_cors_and_frame_headers(response):
    """Allow live preview embedding and relative/proxied origins cleanly."""
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return response


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/compare", methods=["POST"])
def api_compare():
    try:
        data = request.get_json(force=True) or {}
        image = _load_target_image(data)

        aes_mode = str(data.get("aes_mode", "CBC")).upper()
        aes_pass = str(data.get("aes_passphrase", "Exp8-Strong-AES-Secret-2026!"))

        c_params = ChaoticParams(
            passphrase=str(data.get("chaotic_passphrase", "Exp8-Chaotic-Secret-2026!")),
            x0=float(data.get("x0", 0.41728394015263)),
            r=float(data.get("r", 3.99876543210987)),
            arnold_p=int(data.get("arnold_p", 3)),
            arnold_q=int(data.get("arnold_q", 5)),
            arnold_iters=int(data.get("arnold_iters", 4)),
            diffusion_rounds=int(data.get("diffusion_rounds", 2)),
        )

        result = run_full_comparison(
            image=image,
            aes_mode=aes_mode,  # type: ignore[arg-type]
            aes_passphrase=aes_pass,
            chaotic_params=c_params,
            scatter_samples=1400,
        )

        arrays = result.pop("arrays")
        result["images"] = {
            "original": array_to_data_uri(arrays["original"]),
            "aes_cipher": array_to_data_uri(arrays["aes_cipher"]),
            "aes_decrypted": array_to_data_uri(arrays["aes_decrypted"]),
            "chaotic_cipher": array_to_data_uri(arrays["chaotic_cipher"]),
            "chaotic_decrypted": array_to_data_uri(arrays["chaotic_decrypted"]),
        }
        return jsonify({"ok": True, "data": result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.route("/api/exp8", methods=["POST"])
def api_exp8():
    try:
        data = request.get_json(force=True) or {}
        image = _load_target_image(data)
        scheme = str(data.get("scheme", "AES")).upper()
        aes_mode = str(data.get("aes_mode", "GCM")).upper()
        if aes_mode not in ("GCM", "CBC", "CTR"):
            aes_mode = "GCM"
        attack = str(data.get("attack", "none"))

        sim = simulate_exp8_transmission(
            image=image,
            scheme=scheme,  # type: ignore[arg-type]
            aes_mode=aes_mode,  # type: ignore[arg-type]
            attack=attack,  # type: ignore[arg-type]
            vault_dir=VAULT_DIR,
        )

        images_out = {
            "original": array_to_data_uri(image),
            "cipher": array_to_data_uri(sim["cipher_image"]),
            "decrypted": array_to_data_uri(sim["decrypted_image"]) if sim["decrypted_image"] is not None else None,
            "wrong_key": array_to_data_uri(sim["wrong_key_image"]) if sim["wrong_key_image"] is not None else None,
        }

        vault_filename = Path(sim["vault_path"]).name
        return jsonify({
            "ok": True,
            "data": {
                "scheme": sim["scheme"],
                "aes_mode": sim["aes_mode"],
                "attack": sim["attack"],
                "vault_filename": vault_filename,
                "vault_path": sim["vault_path"],
                "alice_fingerprint": sim["alice_fingerprint"],
                "bob_fingerprint": sim["bob_fingerprint"],
                "ciphertext_sha256": sim["ciphertext_sha256"],
                "signature_b64_preview": sim["signature_b64_preview"],
                "channel_notes": sim["channel_notes"],
                "verification": sim["verification"],
                "fidelity": sim["fidelity"],
                "sensitivity_metrics": sim["sensitivity_metrics"],
                "images": images_out,
                "envelope_header": sim["envelope"]["header"],
            },
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.route("/api/vault", methods=["GET"])
def api_vault_list():
    files = sorted(VAULT_DIR.glob("*.secimg.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    items = []
    for f in files[:20]:
        try:
            doc = json.loads(f.read_text(encoding="utf-8"))
            hdr = doc.get("header", {})
            sig = doc.get("digital_signature", {})
            items.append({
                "filename": f.name,
                "size_kb": round(f.stat().st_size / 1024.0, 1),
                "scheme": hdr.get("scheme"),
                "timestamp_utc": hdr.get("timestamp_utc"),
                "sender": hdr.get("sender"),
                "receiver": hdr.get("receiver"),
                "signer_fp": sig.get("signer_fingerprint"),
            })
        except Exception:
            continue
    return jsonify({"ok": True, "items": items})


@app.route("/api/vault/<path:filename>", methods=["GET"])
def api_vault_download(filename: str):
    return send_from_directory(VAULT_DIR, filename, as_attachment=True)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
