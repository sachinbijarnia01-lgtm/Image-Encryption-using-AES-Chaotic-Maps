"""CLI Runner & Automated Lab Report Figure Generator for Experiment 8.

Usage:
    python3 run_experiment.py
"""

from __future__ import annotations

import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

from src.aes_cipher import encrypt_image_aes
from src.chaotic_cipher import ChaoticParams
from src.comparison_pipeline import run_full_comparison
from src.exp8_protocol import simulate_exp8_transmission
from src.sample_images import ensure_sample_images


def generate_visual_comparison_plot(
    badge_img: np.ndarray,
    scene_comp: dict,
    out_path: Path,
) -> None:
    """Create a 2x5 visual comparison grid including AES-ECB structural leakage vs AES-CBC & Chaotic."""
    ecb_badge = encrypt_image_aes(badge_img, mode="ECB").cipher_image
    cbc_badge = encrypt_image_aes(badge_img, mode="CBC").cipher_image
    badge_ch = run_full_comparison(badge_img, aes_mode="GCM")

    fig, axes = plt.subplots(2, 5, figsize=(16, 8.2), dpi=150)
    fig.patch.set_facecolor("#0f172a")

    row1 = [
        (scene_comp["arrays"]["original"], "Original Scene\n(H = " + f"{scene_comp['metrics']['original']['entropy']['global']:.4f} bits)"),
        (scene_comp["arrays"]["aes_cipher"], f"AES-256-{scene_comp['aes_config']['mode']} Cipher\n(H = {scene_comp['metrics']['aes']['entropy']['global']:.4f} bits)"),
        (scene_comp["arrays"]["aes_decrypted"], "AES-256 Decrypted\n(MSE = 0.0, Lossless)"),
        (scene_comp["arrays"]["chaotic_cipher"], f"Chaotic Cipher\n(H = {scene_comp['metrics']['chaotic']['entropy']['global']:.4f} bits)"),
        (scene_comp["arrays"]["chaotic_decrypted"], "Chaotic Decrypted\n(MSE = 0.0, Lossless)"),
    ]

    row2 = [
        (badge_img, "Security Emblem\n(Structured Flat Regions)"),
        (ecb_badge, "AES-256-ECB (Insecure!)\nLeaks Spatial Contours"),
        (cbc_badge, "AES-256-CBC\nUniform Ciphertext"),
        (badge_ch["arrays"]["aes_cipher"], "AES-256-GCM\nAuthenticated Cipher"),
        (badge_ch["arrays"]["chaotic_cipher"], "Chaotic (Arnold+LSCM)\nZero Spatial Leakage"),
    ]

    for r_idx, row in enumerate([row1, row2]):
        for c_idx, (img_arr, title) in enumerate(row):
            ax = axes[r_idx, c_idx]
            ax.imshow(img_arr)
            ax.set_title(title, color="#f1f5f9", fontsize=9.5, fontweight="bold", pad=6)
            ax.axis("off")

    fig.suptitle(
        "Experiment 8: Image Encryption Visual Comparison — AES Modes vs. Chaotic-Map Scheme",
        color="#38bdf8",
        fontsize=13,
        fontweight="bold",
        y=0.98,
    )
    fig.subplots_adjust(left=0.02, right=0.98, bottom=0.03, top=0.88, hspace=0.26, wspace=0.08)
    fig.savefig(out_path, facecolor=fig.get_facecolor())
    plt.close(fig)


def generate_histogram_plot(comp: dict, out_path: Path) -> None:
    """Plot RGB channel histograms for Original, AES-256 Encrypted, and Chaotic Encrypted images."""
    fig, axes = plt.subplots(3, 3, figsize=(14, 9.5), dpi=150, sharex=True)
    fig.patch.set_facecolor("#0f172a")

    rows = [
        ("Original Image", comp["metrics"]["original"]["histogram"]),
        (f"AES-256-{comp['aes_config']['mode']} Encrypted", comp["metrics"]["aes"]["histogram"]),
        ("Chaotic-Map Encrypted", comp["metrics"]["chaotic"]["histogram"]),
    ]
    channels = [("R", "#ef4444", "Red Channel"), ("G", "#22c55e", "Green Channel"), ("B", "#3b82f6", "Blue Channel")]
    bins = np.arange(256)

    for r_idx, (row_label, hist_data) in enumerate(rows):
        for c_idx, (ch_key, color, ch_title) in enumerate(channels):
            ax = axes[r_idx, c_idx]
            ax.set_facecolor("#1e293b")
            vals = hist_data["channels"][ch_key]
            ax.bar(bins, vals, width=1.0, color=color, alpha=0.82)
            ax.set_xlim(0, 255)
            ax.tick_params(colors="#cbd5e1", labelsize=8)
            for spine in ax.spines.values():
                spine.set_color("#334155")
            if r_idx == 0:
                ax.set_title(ch_title, color="#f8fafc", fontsize=10.5, fontweight="bold")
            if c_idx == 0:
                ax.set_ylabel(
                    f"{row_label}\n(χ² = {hist_data['chi_square']})",
                    color="#f8fafc",
                    fontsize=9,
                    fontweight="bold",
                )
            if r_idx == 2:
                ax.set_xlabel("Pixel Intensity (0–255)", color="#cbd5e1", fontsize=8.5)

    fig.suptitle(
        "Histogram Uniformity Analysis: Original vs. AES-256 vs. Chaotic-Map Encryption",
        color="#38bdf8",
        fontsize=13,
        fontweight="bold",
        y=0.98,
    )
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(out_path, facecolor=fig.get_facecolor())
    plt.close(fig)


def generate_correlation_plot(comp: dict, out_path: Path) -> None:
    """Plot 3x3 adjacent pixel correlation scatter matrices (Horizontal, Vertical, Diagonal)."""
    fig, axes = plt.subplots(3, 3, figsize=(13.5, 11), dpi=150)
    fig.patch.set_facecolor("#0f172a")

    rows = [
        ("Original Image", comp["metrics"]["original"]["correlation"], "#f59e0b"),
        (f"AES-256-{comp['aes_config']['mode']}", comp["metrics"]["aes"]["correlation"], "#38bdf8"),
        ("Chaotic-Map", comp["metrics"]["chaotic"]["correlation"], "#a855f7"),
    ]
    dirs = [("horizontal", "Horizontal (x, y) vs (x+1, y)"), ("vertical", "Vertical (x, y) vs (x, y+1)"), ("diagonal", "Diagonal (x, y) vs (x+1, y+1)")]

    for r_idx, (r_label, corr_data, color) in enumerate(rows):
        for c_idx, (d_key, d_title) in enumerate(dirs):
            ax = axes[r_idx, c_idx]
            ax.set_facecolor("#1e293b")
            pts = corr_data["scatter"][d_key]
            r_val = corr_data[d_key]
            ax.scatter(pts["x"], pts["y"], s=2.2, c=color, alpha=0.55, edgecolors="none")
            ax.set_xlim(0, 255)
            ax.set_ylim(0, 255)
            ax.tick_params(colors="#cbd5e1", labelsize=8)
            for spine in ax.spines.values():
                spine.set_color("#334155")
            ax.set_title(f"{r_label} — {d_key.capitalize()}\nr = {r_val:+.5f}", color="#f8fafc", fontsize=9.2, fontweight="bold")
            if r_idx == 2:
                ax.set_xlabel("Pixel(i) Intensity", color="#cbd5e1", fontsize=8.5)
            if c_idx == 0:
                ax.set_ylabel("Adjacent Pixel(i+1)", color="#cbd5e1", fontsize=8.5)

    fig.suptitle(
        "Adjacent Pixel Correlation Analysis (Horizontal, Vertical & Diagonal Directions)",
        color="#38bdf8",
        fontsize=13,
        fontweight="bold",
        y=0.98,
    )
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(out_path, facecolor=fig.get_facecolor())
    plt.close(fig)


def generate_exp8_sensitivity_plot(image: np.ndarray, exp8_wrong_key: dict, out_path: Path) -> None:
    """Visualize Exp 8 Chaotic Key Sensitivity (Delta x0 = 10^-14) & Signed Recovery."""
    fig, axes = plt.subplots(1, 4, figsize=(14, 3.8), dpi=150)
    fig.patch.set_facecolor("#0f172a")

    panels = [
        (image, "1. Sender Original Image\n(Signed with RSA-2048-PSS)"),
        (exp8_wrong_key["cipher_image"], "2. Transmitted Ciphertext\n(Wrapped via RSA-2048-OAEP)"),
        (exp8_wrong_key["decrypted_image"], "3. Authorized Receiver (Bob)\nExact Key → MSE = 0.0"),
        (
            exp8_wrong_key["wrong_key_image"],
            f"4. Wrong Key (x0 + 10⁻¹⁴)\nNPCR = {exp8_wrong_key['sensitivity_metrics']['npcr']}% (Pure Noise)",
        ),
    ]
    for ax, (arr, title) in zip(axes, panels):
        ax.imshow(arr)
        ax.set_title(title, color="#f8fafc", fontsize=9.5, fontweight="bold")
        ax.axis("off")

    fig.suptitle(
        "Exp 8 – Secure Transmission, Digital Signature Verification & 10⁻¹⁴ Chaotic Key Sensitivity",
        color="#38bdf8",
        fontsize=12.5,
        fontweight="bold",
        y=0.98,
    )
    plt.tight_layout(rect=[0, 0, 1, 0.90])
    fig.savefig(out_path, facecolor=fig.get_facecolor())
    plt.close(fig)


def main() -> None:
    samples = ensure_sample_images("samples")
    out_dir = Path("outputs")
    out_dir.mkdir(parents=True, exist_ok=True)

    scene_img = np.asarray(Image.open(samples["natural_scene"]).convert("RGB"))
    badge_img = np.asarray(Image.open(samples["security_badge"]).convert("RGB"))

    print("=" * 84)
    print("  EXPERIMENT 8: IMAGE ENCRYPTION USING AES-256 & CHAOTIC MAPS")
    print("  Secure Storage, Transmission & Digital Signature — Automated Evaluation")
    print("=" * 84)

    comp = run_full_comparison(
        scene_img,
        aes_mode="CBC",
        chaotic_params=ChaoticParams(),
    )

    # Also evaluate AES-GCM for completeness
    comp_gcm = run_full_comparison(scene_img, aes_mode="GCM")

    m_orig = comp["metrics"]["original"]
    m_aes = comp["metrics"]["aes"]
    m_aes_gcm = comp_gcm["metrics"]["aes"]
    m_ch = comp["metrics"]["chaotic"]

    print("\n[1] STATISTICAL & CRYPTOGRAPHIC COMPARISON (256x256 RGB Natural Landscape)")
    print("-" * 84)
    header_fmt = f"{'Metric':<30} | {'Original':<12} | {'AES-256-CBC':<12} | {'AES-256-GCM':<12} | {'Chaotic Map':<12}"
    print(header_fmt)
    print("-" * 84)
    rows = [
        ("Shannon Entropy (Ideal=8.0)", f"{m_orig['entropy']['global']:.5f}", f"{m_aes['entropy']['global']:.5f}", f"{m_aes_gcm['entropy']['global']:.5f}", f"{m_ch['entropy']['global']:.5f}"),
        ("Histogram Chi-Square (χ²)", f"{m_orig['histogram']['chi_square']:.1f}", f"{m_aes['histogram']['chi_square']:.1f}", f"{m_aes_gcm['histogram']['chi_square']:.1f}", f"{m_ch['histogram']['chi_square']:.1f}"),
        ("Corr. Horizontal (r_H)", f"{m_orig['correlation']['horizontal']:+.5f}", f"{m_aes['correlation']['horizontal']:+.5f}", f"{m_aes_gcm['correlation']['horizontal']:+.5f}", f"{m_ch['correlation']['horizontal']:+.5f}"),
        ("Corr. Vertical (r_V)", f"{m_orig['correlation']['vertical']:+.5f}", f"{m_aes['correlation']['vertical']:+.5f}", f"{m_aes_gcm['correlation']['vertical']:+.5f}", f"{m_ch['correlation']['vertical']:+.5f}"),
        ("Corr. Diagonal (r_D)", f"{m_orig['correlation']['diagonal']:+.5f}", f"{m_aes['correlation']['diagonal']:+.5f}", f"{m_aes_gcm['correlation']['diagonal']:+.5f}", f"{m_ch['correlation']['diagonal']:+.5f}"),
        ("NPCR % (Ideal=99.6094%)", "N/A", f"{m_aes['differential']['npcr']:.4f}%", f"{m_aes_gcm['differential']['npcr']:.4f}%", f"{m_ch['differential']['npcr']:.4f}%"),
        ("UACI % (Ideal=33.4635%)", "N/A", f"{m_aes['differential']['uaci']:.4f}%", f"{m_aes_gcm['differential']['uaci']:.4f}%", f"{m_ch['differential']['uaci']:.4f}%"),
        ("Decryption MSE (Lossless=0)", "0.0", f"{m_aes['decryption_fidelity']['mse']}", f"{m_aes_gcm['decryption_fidelity']['mse']}", f"{m_ch['decryption_fidelity']['mse']}"),
        ("Encrypt Time (ms)", "-", f"{comp['aes_config']['encrypt_ms']:.2f} ms", f"{comp_gcm['aes_config']['encrypt_ms']:.2f} ms", f"{comp['chaotic_config']['encrypt_ms']:.2f} ms"),
    ]
    for label, c0, c1, c2, c3 in rows:
        print(f"{label:<30} | {c0:<12} | {c1:<12} | {c2:<12} | {c3:<12}")

    # Run Exp 8 Protocol Scenarios
    print("\n[2] EXP 8 – SECURE STORAGE, TRANSMISSION & DIGITAL SIGNATURE SCENARIOS")
    print("-" * 84)
    exp8_clean_aes = simulate_exp8_transmission(scene_img, scheme="AES", aes_mode="GCM", attack="none")
    exp8_clean_ch = simulate_exp8_transmission(scene_img, scheme="CHAOTIC", attack="wrong_chaotic_key")
    exp8_tamper = simulate_exp8_transmission(scene_img, scheme="AES", aes_mode="GCM", attack="tamper_ciphertext")
    exp8_forged = simulate_exp8_transmission(scene_img, scheme="CHAOTIC", attack="forge_signature")

    for name, res in [
        ("Scenario A: Clean AES-256-GCM + RSA-PSS Signed Transmission", exp8_clean_aes),
        ("Scenario B: Clean Chaotic + RSA-PSS Signed (+ 10^-14 Key Test)", exp8_clean_ch),
        ("Scenario C: Active 1-Bit Ciphertext Tampering Attack", exp8_tamper),
        ("Scenario D: Rogue Mallory Digital Signature Forgery Attack", exp8_forged),
    ]:
        v = res["verification"]
        status = "VERIFIED & DECRYPTED" if v["success"] else f"BLOCKED ({v['stage_failed']})"
        print(f"• {name}: {status}")
        for log_line in v["logs"]:
            print(f"    -> {log_line}")

    # Generate high-res figures
    generate_visual_comparison_plot(badge_img, comp, out_dir / "visual_comparison.png")
    generate_histogram_plot(comp, out_dir / "histogram_analysis.png")
    generate_correlation_plot(comp, out_dir / "correlation_analysis.png")
    generate_exp8_sensitivity_plot(scene_img, exp8_clean_ch, out_dir / "exp8_security_demo.png")

    # Save structured JSON summary (without bulky scatter arrays)
    def _strip_scatter(stats: dict) -> dict:
        out = dict(stats)
        corr = dict(out["correlation"])
        corr.pop("scatter", None)
        out["correlation"] = corr
        hist = dict(out["histogram"])
        hist.pop("channels", None)
        out["histogram"] = hist
        return out

    report = {
        "experiment": "Exp 8 – Image Encryption using AES & Chaotic Maps (Secure Storage, Transmission & Digital Signature)",
        "image_tested": "samples/natural_scene.png (256x256 RGB)",
        "metrics_summary": {
            "original": _strip_scatter(m_orig),
            "aes_256_cbc": _strip_scatter(m_aes),
            "aes_256_gcm": _strip_scatter(m_aes_gcm),
            "chaotic_arnold_lscm": _strip_scatter(m_ch),
        },
        "exp8_scenarios": {
            "clean_aes_gcm": exp8_clean_aes["verification"],
            "clean_chaotic_with_key_sensitivity": {
                **exp8_clean_ch["verification"],
                "wrong_key_1e-14_sensitivity": exp8_clean_ch["sensitivity_metrics"],
            },
            "tamper_1bit_attack": exp8_tamper["verification"],
            "forged_signature_attack": exp8_forged["verification"],
        },
        "generated_figures": [
            "outputs/visual_comparison.png",
            "outputs/histogram_analysis.png",
            "outputs/correlation_analysis.png",
            "outputs/exp8_security_demo.png",
        ],
    }
    (out_dir / "metrics_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("\n[+] Saved visual lab charts & JSON report to 'outputs/' and signed envelopes to 'vault/'.")


if __name__ == "__main__":
    main()
