"""Image Encryption using AES & Chaotic Maps - Exp 8 Mini Project."""
