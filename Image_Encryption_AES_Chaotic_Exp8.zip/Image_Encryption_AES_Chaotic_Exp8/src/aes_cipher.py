"""AES-256 Image Encryption & Decryption Engine (GCM, CBC, CTR, ECB)."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import os
import time
from typing import Literal
import numpy as np
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

AESMode = Literal["GCM", "CBC", "CTR", "ECB"]


@dataclass
class AESResult:
    cipher_image: np.ndarray          # Visual (H, W, C) or (H, W) uint8 cipher image
    ciphertext: bytes                 # Full raw ciphertext bytes (includes PKCS7 pad if CBC/ECB)
    mode: AESMode
    salt: bytes
    iv_or_nonce: bytes
    auth_tag: bytes | None            # 16-byte tag for GCM
    original_shape: tuple[int, ...]
    key_fingerprint: str              # SHA-256 short hex of derived 256-bit key
    encrypt_time_ms: float


def derive_aes256_key(passphrase: str, salt: bytes, iterations: int = 100_000) -> bytes:
    """Derive a 256-bit (32-byte) AES key from a passphrase using PBKDF2-HMAC-SHA256."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=iterations,
    )
    return kdf.derive(passphrase.encode("utf-8"))


def encrypt_image_aes(
    image_array: np.ndarray,
    passphrase: str = "Exp8-Strong-AES-Secret-2026!",
    mode: AESMode = "GCM",
    salt: bytes | None = None,
    iv_or_nonce: bytes | None = None,
    raw_key: bytes | None = None,
    associated_data: bytes = b"EXP8-AES-IMAGE-ENCRYPTION",
) -> AESResult:
    """Encrypt a NumPy uint8 image array using AES-256."""
    if image_array.dtype != np.uint8:
        image_array = image_array.astype(np.uint8)

    mode = mode.upper()  # type: ignore[assignment]
    if mode not in ("GCM", "CBC", "CTR", "ECB"):
        raise ValueError(f"Unsupported AES mode: {mode}")

    salt = salt if salt is not None else os.urandom(16)
    key = raw_key if raw_key is not None else derive_aes256_key(passphrase, salt)
    if len(key) != 32:
        raise ValueError("AES-256 key must be exactly 32 bytes.")

    orig_shape = image_array.shape
    raw_bytes = image_array.tobytes()
    n_bytes = len(raw_bytes)

    t0 = time.perf_counter()

    if mode == "GCM":
        nonce = iv_or_nonce if iv_or_nonce is not None else os.urandom(12)
        encryptor = Cipher(algorithms.AES(key), modes.GCM(nonce)).encryptor()
        if associated_data:
            encryptor.authenticate_additional_data(associated_data)
        ciphertext = encryptor.update(raw_bytes) + encryptor.finalize()
        auth_tag = encryptor.tag
        iv_used = nonce

    elif mode == "CTR":
        nonce = iv_or_nonce if iv_or_nonce is not None else os.urandom(16)
        encryptor = Cipher(algorithms.AES(key), modes.CTR(nonce)).encryptor()
        ciphertext = encryptor.update(raw_bytes) + encryptor.finalize()
        auth_tag = None
        iv_used = nonce

    elif mode == "CBC":
        iv = iv_or_nonce if iv_or_nonce is not None else os.urandom(16)
        padder = padding.PKCS7(128).padder()
        padded = padder.update(raw_bytes) + padder.finalize()
        encryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).encryptor()
        ciphertext = encryptor.update(padded) + encryptor.finalize()
        auth_tag = None
        iv_used = iv

    elif mode == "ECB":
        iv_used = b""
        padder = padding.PKCS7(128).padder()
        padded = padder.update(raw_bytes) + padder.finalize()
        encryptor = Cipher(algorithms.AES(key), modes.ECB()).encryptor()
        ciphertext = encryptor.update(padded) + encryptor.finalize()
        auth_tag = None

    elapsed_ms = (time.perf_counter() - t0) * 1000.0

    # Form visual cipher image from first n_bytes of ciphertext
    cipher_img = np.frombuffer(ciphertext[:n_bytes], dtype=np.uint8).copy().reshape(orig_shape)
    key_fp = hashlib.sha256(key).hexdigest()[:16]

    return AESResult(
        cipher_image=cipher_img,
        ciphertext=ciphertext,
        mode=mode,
        salt=salt,
        iv_or_nonce=iv_used,
        auth_tag=auth_tag,
        original_shape=orig_shape,
        key_fingerprint=key_fp,
        encrypt_time_ms=elapsed_ms,
    )


def decrypt_image_aes(
    aes_result: AESResult,
    passphrase: str = "Exp8-Strong-AES-Secret-2026!",
    raw_key: bytes | None = None,
    associated_data: bytes = b"EXP8-AES-IMAGE-ENCRYPTION",
) -> tuple[np.ndarray, float]:
    """Decrypt an AESResult back into the exact uint8 NumPy image array."""
    key = raw_key if raw_key is not None else derive_aes256_key(passphrase, aes_result.salt)
    mode = aes_result.mode.upper()

    t0 = time.perf_counter()

    if mode == "GCM":
        if aes_result.auth_tag is None:
            raise ValueError("GCM mode requires authentication tag.")
        decryptor = Cipher(
            algorithms.AES(key),
            modes.GCM(aes_result.iv_or_nonce, aes_result.auth_tag),
        ).decryptor()
        if associated_data:
            decryptor.authenticate_additional_data(associated_data)
        plain_bytes = decryptor.update(aes_result.ciphertext) + decryptor.finalize()

    elif mode == "CTR":
        decryptor = Cipher(algorithms.AES(key), modes.CTR(aes_result.iv_or_nonce)).decryptor()
        plain_bytes = decryptor.update(aes_result.ciphertext) + decryptor.finalize()

    elif mode == "CBC":
        decryptor = Cipher(algorithms.AES(key), modes.CBC(aes_result.iv_or_nonce)).decryptor()
        padded = decryptor.update(aes_result.ciphertext) + decryptor.finalize()
        unpadder = padding.PKCS7(128).unpadder()
        plain_bytes = unpadder.update(padded) + unpadder.finalize()

    elif mode == "ECB":
        decryptor = Cipher(algorithms.AES(key), modes.ECB()).decryptor()
        padded = decryptor.update(aes_result.ciphertext) + decryptor.finalize()
        unpadder = padding.PKCS7(128).unpadder()
        plain_bytes = unpadder.update(padded) + unpadder.finalize()

    else:
        raise ValueError(f"Unsupported AES mode: {mode}")

    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    recovered = np.frombuffer(plain_bytes, dtype=np.uint8).copy().reshape(aes_result.original_shape)
    return recovered, elapsed_ms
