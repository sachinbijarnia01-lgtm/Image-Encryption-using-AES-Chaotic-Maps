"""Side-by-side AES vs Chaotic-Map Image Encryption & Statistical Analysis Pipeline."""

from __future__ import annotations

import base64
import io
from typing import Any
import numpy as np
from PIL import Image

from src.aes_cipher import AESMode, decrypt_image_aes, encrypt_image_aes
from src.chaotic_cipher import ChaoticParams, decrypt_image_chaotic, encrypt_image_chaotic
from src.metrics import (
    analyze_single_image,
    compute_mse_psnr,
    compute_npcr_uaci,
)


def array_to_data_uri(arr: np.ndarray) -> str:
    """Encode a uint8 NumPy array as a PNG base64 data URI."""
    img = Image.fromarray(arr.astype(np.uint8))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    return f"data:image/png;base64,{b64}"


def run_full_comparison(
    image: np.ndarray,
    aes_mode: AESMode = "CBC",
    aes_passphrase: str = "Exp8-Strong-AES-Secret-2026!",
    chaotic_params: ChaoticParams | None = None,
    scatter_samples: int = 1600,
) -> dict[str, Any]:
    """Encrypt image with both AES-256 and Chaotic Map, verify lossless decryption, and compare metrics."""
    if image.dtype != np.uint8:
        image = image.astype(np.uint8)
    c_params = chaotic_params or ChaoticParams()

    # 1. AES Encryption & Decryption
    aes_enc = encrypt_image_aes(image, passphrase=aes_passphrase, mode=aes_mode)
    aes_dec, aes_dec_ms = decrypt_image_aes(aes_enc, passphrase=aes_passphrase)

    # 2. Chaotic Encryption & Decryption
    ch_enc = encrypt_image_chaotic(image, params=c_params)
    ch_dec, ch_dec_ms = decrypt_image_chaotic(ch_enc.cipher_image, params=c_params)

    # 3. Differential Attack Analysis (1-pixel LSB modification at top-left pixel)
    perturbed = image.copy()
    if perturbed.ndim == 3:
        perturbed[0, 0, 0] = np.uint8(int(perturbed[0, 0, 0]) ^ 1)
    else:
        perturbed[0, 0] = np.uint8(int(perturbed[0, 0]) ^ 1)

    aes_enc_diff = encrypt_image_aes(
        perturbed,
        passphrase=aes_passphrase,
        mode=aes_mode,
        salt=aes_enc.salt,
        iv_or_nonce=aes_enc.iv_or_nonce,
    )
    ch_enc_diff = encrypt_image_chaotic(perturbed, params=c_params)

    aes_diff_metrics = compute_npcr_uaci(aes_enc.cipher_image, aes_enc_diff.cipher_image)
    ch_diff_metrics = compute_npcr_uaci(ch_enc.cipher_image, ch_enc_diff.cipher_image)

    # 4. Statistical Analysis (Histogram, Correlation, Entropy)
    orig_stats = analyze_single_image(image, sample_size=scatter_samples)
    aes_stats = analyze_single_image(aes_enc.cipher_image, sample_size=scatter_samples)
    ch_stats = analyze_single_image(ch_enc.cipher_image, sample_size=scatter_samples)

    # 5. Fidelity checks (Original vs Cipher & Original vs Decrypted)
    aes_cipher_dist = compute_mse_psnr(image, aes_enc.cipher_image)
    aes_recovery = compute_mse_psnr(image, aes_dec)
    ch_cipher_dist = compute_mse_psnr(image, ch_enc.cipher_image)
    ch_recovery = compute_mse_psnr(image, ch_dec)

    return {
        "image_shape": list(image.shape),
        "aes_config": {
            "mode": aes_enc.mode,
            "key_fingerprint": aes_enc.key_fingerprint,
            "encrypt_ms": round(aes_enc.encrypt_time_ms, 2),
            "decrypt_ms": round(aes_dec_ms, 2),
        },
        "chaotic_config": {
            "x0": c_params.x0,
            "r": c_params.r,
            "arnold_p": c_params.arnold_p,
            "arnold_q": c_params.arnold_q,
            "arnold_iters": c_params.arnold_iters,
            "diffusion_rounds": c_params.diffusion_rounds,
            "key_fingerprint": ch_enc.key_fingerprint,
            "encrypt_ms": round(ch_enc.encrypt_time_ms, 2),
            "decrypt_ms": round(ch_dec_ms, 2),
        },
        "metrics": {
            "original": orig_stats,
            "aes": {
                **aes_stats,
                "differential": aes_diff_metrics,
                "vs_original": aes_cipher_dist,
                "decryption_fidelity": aes_recovery,
            },
            "chaotic": {
                **ch_stats,
                "differential": ch_diff_metrics,
                "vs_original": ch_cipher_dist,
                "decryption_fidelity": ch_recovery,
            },
        },
        "arrays": {
            "original": image,
            "aes_cipher": aes_enc.cipher_image,
            "aes_decrypted": aes_dec,
            "chaotic_cipher": ch_enc.cipher_image,
            "chaotic_decrypted": ch_dec,
        },
    }
