"""Exp 8 – Secure Storage, Transmission & Digital Signature Protocol.

Implements:
1. Asymmetric PKI Key Generation (RSA-2048 for PSS Digital Signatures & OAEP Key Wrapping,
   plus optional ECDSA-P256 signing).
2. Authenticated Secure Image Envelope (.secimg) for Secure Storage Vault & Network Transmission.
3. End-to-End Sender (Alice) -> Channel -> Receiver (Bob) Verification Pipeline.
4. Active Attack & Key-Sensitivity Demonstrations (Bit-flip Tampering, Forged Signature,
   10^-14 Chaotic Key Perturbation).
"""

from __future__ import annotations

import base64
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import time
from typing import Any, Literal

import numpy as np
from cryptography.exceptions import InvalidSignature, InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.primitives.asymmetric import rsa

from src.aes_cipher import AESResult, decrypt_image_aes, encrypt_image_aes
from src.chaotic_cipher import ChaoticParams, decrypt_image_chaotic, encrypt_image_chaotic
from src.metrics import compute_mse_psnr, compute_npcr_uaci


class IdentityKeys:
    """Holds RSA-2048 keypair for signing (RSA-PSS) and key encapsulation (RSA-OAEP)."""

    def __init__(self, name: str, private_key: rsa.RSAPrivateKey):
        self.name = name
        self.private_key = private_key
        self.public_key = private_key.public_key()

    @classmethod
    def generate(cls, name: str, key_size: int = 2048) -> "IdentityKeys":
        priv = rsa.generate_private_key(public_exponent=65537, key_size=key_size)
        return cls(name=name, private_key=priv)

    def public_pem(self) -> str:
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode("utf-8")

    def fingerprint(self) -> str:
        der = self.public_key.public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        return hashlib.sha256(der).hexdigest()[:20]


def _canonical_signing_payload(header: dict[str, Any], wrapped_key_b64: str, ciphertext_bytes: bytes) -> bytes:
    """Create deterministic bytes over envelope header, wrapped key, and ciphertext SHA-256."""
    ct_hash = hashlib.sha256(ciphertext_bytes).hexdigest()
    doc = {
        "header": header,
        "wrapped_secret_key": wrapped_key_b64,
        "ciphertext_sha256": ct_hash,
    }
    return json.dumps(doc, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sign_bytes_rsa_pss(private_key: rsa.RSAPrivateKey, data: bytes) -> bytes:
    """Sign data using RSA-2048-PSS with SHA-256."""
    return private_key.sign(
        data,
        asym_padding.PSS(
            mgf=asym_padding.MGF1(hashes.SHA256()),
            salt_length=asym_padding.PSS.MAX_LENGTH,
        ),
        hashes.SHA256(),
    )


def verify_signature_rsa_pss(public_pem: str, data: bytes, signature: bytes) -> bool:
    """Verify RSA-PSS SHA-256 digital signature."""
    pub = serialization.load_pem_public_key(public_pem.encode("utf-8"))
    try:
        pub.verify(  # type: ignore[union-attr]
            signature,
            data,
            asym_padding.PSS(
                mgf=asym_padding.MGF1(hashes.SHA256()),
                salt_length=asym_padding.PSS.MAX_LENGTH,
            ),
            hashes.SHA256(),
        )
        return True
    except InvalidSignature:
        return False


def wrap_secret_rsa_oaep(receiver_pub_pem: str, secret_dict: dict[str, Any]) -> bytes:
    """Encrypt session secret dictionary with Receiver's RSA-2048-OAEP public key."""
    pub = serialization.load_pem_public_key(receiver_pub_pem.encode("utf-8"))
    raw = json.dumps(secret_dict, separators=(",", ":")).encode("utf-8")
    return pub.encrypt(  # type: ignore[union-attr]
        raw,
        asym_padding.OAEP(
            mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=b"EXP8-KEY-WRAP",
        ),
    )


def unwrap_secret_rsa_oaep(receiver_priv: rsa.RSAPrivateKey, wrapped_bytes: bytes) -> dict[str, Any]:
    """Decrypt session secret dictionary using Receiver's RSA-2048-OAEP private key."""
    raw = receiver_priv.decrypt(
        wrapped_bytes,
        asym_padding.OAEP(
            mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=b"EXP8-KEY-WRAP",
        ),
    )
    return json.loads(raw.decode("utf-8"))


def create_secure_envelope(
    image: np.ndarray,
    sender: IdentityKeys,
    receiver_pub_pem: str,
    receiver_name: str = "Bob (Receiver)",
    scheme: Literal["AES", "CHAOTIC"] = "AES",
    aes_mode: Literal["GCM", "CBC", "CTR"] = "GCM",
    chaotic_params: ChaoticParams | None = None,
) -> tuple[dict[str, Any], np.ndarray]:
    """Encrypt image, wrap session key with Receiver's RSA-OAEP key, and sign with Sender's RSA-PSS key."""
    plain_sha256 = hashlib.sha256(image.tobytes()).hexdigest()
    now_iso = datetime.now(timezone.utc).isoformat()

    if scheme.upper() == "AES":
        ephemeral_key = os.urandom(32)
        aes_res = encrypt_image_aes(image, mode=aes_mode, raw_key=ephemeral_key)
        ciphertext_bytes = aes_res.ciphertext
        cipher_preview = aes_res.cipher_image

        header = {
            "protocol": "EXP8-SECIMG-v1",
            "timestamp_utc": now_iso,
            "sender": sender.name,
            "receiver": receiver_name,
            "scheme": "AES",
            "aes_mode": aes_res.mode,
            "image_shape": list(aes_res.original_shape),
            "iv_or_nonce_b64": base64.b64encode(aes_res.iv_or_nonce).decode("ascii"),
            "auth_tag_b64": base64.b64encode(aes_res.auth_tag).decode("ascii") if aes_res.auth_tag else None,
            "salt_b64": base64.b64encode(aes_res.salt).decode("ascii"),
        }
        secret_payload = {
            "k": base64.b64encode(ephemeral_key).decode("ascii"),
            "pt_sha256": plain_sha256,
        }
    else:
        c_params = chaotic_params or ChaoticParams()
        ch_res = encrypt_image_chaotic(image, c_params)
        ciphertext_bytes = ch_res.cipher_image.tobytes()
        cipher_preview = ch_res.cipher_image

        header = {
            "protocol": "EXP8-SECIMG-v1",
            "timestamp_utc": now_iso,
            "sender": sender.name,
            "receiver": receiver_name,
            "scheme": "CHAOTIC",
            "chaotic_map": "2D-Arnold + Logistic-Sine-ARX",
            "image_shape": list(ch_res.original_shape),
            "arnold_p": c_params.arnold_p,
            "arnold_q": c_params.arnold_q,
            "arnold_iters": c_params.arnold_iters,
            "diffusion_rounds": c_params.diffusion_rounds,
        }
        # Keep secret payload compact (<190 bytes for RSA-2048-OAEP-SHA256)
        secret_payload = {
            "pw": c_params.passphrase[:32],
            "x0": c_params.x0,
            "r": c_params.r,
            "pt_sha256": plain_sha256[:32],
        }

    wrapped_key = wrap_secret_rsa_oaep(receiver_pub_pem, secret_payload)
    wrapped_key_b64 = base64.b64encode(wrapped_key).decode("ascii")

    canonical_bytes = _canonical_signing_payload(header, wrapped_key_b64, ciphertext_bytes)
    signature = sign_bytes_rsa_pss(sender.private_key, canonical_bytes)

    envelope = {
        "header": header,
        "wrapped_secret_key": wrapped_key_b64,
        "ciphertext_sha256": hashlib.sha256(ciphertext_bytes).hexdigest(),
        "ciphertext_b64": base64.b64encode(ciphertext_bytes).decode("ascii"),
        "digital_signature": {
            "algorithm": "RSA-2048-PSS-SHA256",
            "signer_name": sender.name,
            "signer_fingerprint": sender.fingerprint(),
            "signer_public_key_pem": sender.public_pem(),
            "signature_b64": base64.b64encode(signature).decode("ascii"),
        },
    }
    return envelope, cipher_preview


def verify_and_open_envelope(
    envelope: dict[str, Any],
    receiver: IdentityKeys,
    trusted_signer_pem: str | None = None,
) -> dict[str, Any]:
    """Verify digital signature, unwrap session key, decrypt payload, and verify plaintext digest."""
    logs: list[str] = []
    t0 = time.perf_counter()

    header = envelope["header"]
    wrapped_key_b64 = envelope["wrapped_secret_key"]
    ciphertext_bytes = base64.b64decode(envelope["ciphertext_b64"])
    sig_info = envelope["digital_signature"]
    signature = base64.b64decode(sig_info["signature_b64"])

    # Step 1: Verify Trusted Signer Public Key & Digital Signature
    pub_pem_to_use = trusted_signer_pem if trusted_signer_pem is not None else sig_info["signer_public_key_pem"]
    canonical_bytes = _canonical_signing_payload(header, wrapped_key_b64, ciphertext_bytes)
    sig_valid = verify_signature_rsa_pss(pub_pem_to_use, canonical_bytes, signature)

    if not sig_valid:
        logs.append("CRITICAL: RSA-2048-PSS Digital Signature verification FAILED! Envelope tampered or forged.")
        return {
            "success": False,
            "signature_valid": False,
            "integrity_valid": False,
            "stage_failed": "digital_signature",
            "logs": logs,
            "decrypted_image": None,
            "elapsed_ms": round((time.perf_counter() - t0) * 1000.0, 2),
        }

    logs.append(f"PASS: RSA-2048-PSS Digital Signature verified (Signer FP: {sig_info['signer_fingerprint']}).")

    # Step 2: Unwrap Session Key via Receiver RSA-2048-OAEP Private Key
    try:
        secret_payload = unwrap_secret_rsa_oaep(receiver.private_key, base64.b64decode(wrapped_key_b64))
        logs.append(f"PASS: Session key unwrapped via {receiver.name}'s RSA-2048-OAEP private key.")
    except Exception as exc:
        logs.append(f"CRITICAL: RSA-OAEP key unwrapping failed: {exc}")
        return {
            "success": False,
            "signature_valid": True,
            "integrity_valid": False,
            "stage_failed": "key_unwrap",
            "logs": logs,
            "decrypted_image": None,
            "elapsed_ms": round((time.perf_counter() - t0) * 1000.0, 2),
        }

    # Step 3: Decrypt Ciphertext
    shape = tuple(header["image_shape"])
    try:
        if header["scheme"] == "AES":
            raw_key = base64.b64decode(secret_payload["k"])
            aes_stub = AESResult(
                cipher_image=np.zeros(shape, dtype=np.uint8),
                ciphertext=ciphertext_bytes,
                mode=header["aes_mode"],
                salt=base64.b64decode(header["salt_b64"]),
                iv_or_nonce=base64.b64decode(header["iv_or_nonce_b64"]),
                auth_tag=base64.b64decode(header["auth_tag_b64"]) if header.get("auth_tag_b64") else None,
                original_shape=shape,
                key_fingerprint="",
                encrypt_time_ms=0.0,
            )
            recovered, dec_ms = decrypt_image_aes(aes_stub, raw_key=raw_key)
            expected_pt_hash = secret_payload["pt_sha256"]
            actual_pt_hash = hashlib.sha256(recovered.tobytes()).hexdigest()
            integrity_ok = (actual_pt_hash == expected_pt_hash)
        else:
            c_params = ChaoticParams(
                passphrase=secret_payload["pw"],
                x0=float(secret_payload["x0"]),
                r=float(secret_payload["r"]),
                arnold_p=int(header["arnold_p"]),
                arnold_q=int(header["arnold_q"]),
                arnold_iters=int(header["arnold_iters"]),
                diffusion_rounds=int(header["diffusion_rounds"]),
            )
            cipher_arr = np.frombuffer(ciphertext_bytes, dtype=np.uint8).copy().reshape(shape)
            recovered, dec_ms = decrypt_image_chaotic(cipher_arr, c_params)
            expected_prefix = secret_payload["pt_sha256"]
            actual_pt_hash = hashlib.sha256(recovered.tobytes()).hexdigest()
            integrity_ok = actual_pt_hash.startswith(expected_prefix)

        logs.append(f"PASS: Payload decrypted using {header['scheme']} in {dec_ms:.2f} ms.")
    except InvalidTag:
        logs.append("CRITICAL: AES-GCM Authentication Tag mismatch! Ciphertext integrity compromised.")
        return {
            "success": False,
            "signature_valid": sig_valid,
            "integrity_valid": False,
            "stage_failed": "gcm_auth_tag",
            "logs": logs,
            "decrypted_image": None,
            "elapsed_ms": round((time.perf_counter() - t0) * 1000.0, 2),
        }
    except Exception as exc:
        logs.append(f"CRITICAL: Decryption error: {exc}")
        return {
            "success": False,
            "signature_valid": sig_valid,
            "integrity_valid": False,
            "stage_failed": "decryption",
            "logs": logs,
            "decrypted_image": None,
            "elapsed_ms": round((time.perf_counter() - t0) * 1000.0, 2),
        }

    if integrity_ok:
        logs.append(f"PASS: Plaintext SHA-256 digest verified ({actual_pt_hash[:16]}...). Zero bit errors.")
    else:
        logs.append("CRITICAL: Decrypted image SHA-256 mismatch!")

    return {
        "success": bool(sig_valid and integrity_ok),
        "signature_valid": sig_valid,
        "integrity_valid": integrity_ok,
        "stage_failed": None if (sig_valid and integrity_ok) else "plaintext_hash",
        "logs": logs,
        "decrypted_image": recovered,
        "elapsed_ms": round((time.perf_counter() - t0) * 1000.0, 2),
    }


def save_envelope_to_vault(envelope: dict[str, Any], vault_dir: str | Path = "vault", filename: str | None = None) -> str:
    """Persist a signed .secimg envelope into the Secure Storage Vault."""
    vdir = Path(vault_dir)
    vdir.mkdir(parents=True, exist_ok=True)
    if filename is None:
        scheme = envelope["header"]["scheme"].lower()
        fp = envelope["ciphertext_sha256"][:10]
        filename = f"exp8_{scheme}_{fp}.secimg.json"
    out_path = vdir / filename
    out_path.write_text(json.dumps(envelope, indent=2), encoding="utf-8")
    return str(out_path)


def simulate_exp8_transmission(
    image: np.ndarray,
    scheme: Literal["AES", "CHAOTIC"] = "AES",
    aes_mode: Literal["GCM", "CBC", "CTR"] = "GCM",
    attack: Literal["none", "tamper_ciphertext", "forge_signature", "wrong_chaotic_key"] = "none",
    vault_dir: str | Path = "vault",
) -> dict[str, Any]:
    """Run full Alice -> Secure Vault -> Channel (with optional Attack) -> Bob pipeline."""
    alice = IdentityKeys.generate("Alice (Sender)")
    bob = IdentityKeys.generate("Bob (Receiver)")
    chaotic_params = ChaoticParams()

    envelope, cipher_img = create_secure_envelope(
        image=image,
        sender=alice,
        receiver_pub_pem=bob.public_pem(),
        receiver_name=bob.name,
        scheme=scheme,
        aes_mode=aes_mode,
        chaotic_params=chaotic_params,
    )

    vault_path = save_envelope_to_vault(envelope, vault_dir=vault_dir)

    # Clone transmitted copy for channel simulation
    transmitted = json.loads(json.dumps(envelope))
    channel_notes: list[str] = [
        f"Alice generated RSA-2048 keypair (FP: {alice.fingerprint()}).",
        f"Bob generated RSA-2048 keypair (FP: {bob.fingerprint()}).",
        f"Encrypted {image.shape} image using {scheme}" + (f"-{aes_mode}" if scheme == "AES" else " (Arnold + LSCM-ARX)") + ".",
        f"Stored signed secure envelope at '{vault_path}'.",
    ]

    wrong_key_image = None
    sensitivity_metrics = None

    if attack == "tamper_ciphertext":
        ct = bytearray(base64.b64decode(transmitted["ciphertext_b64"]))
        mid = len(ct) // 2
        ct[mid] ^= 0x01  # Flip exactly 1 bit in transit
        transmitted["ciphertext_b64"] = base64.b64encode(bytes(ct)).decode("ascii")
        channel_notes.append("ATTACK INJECTED: Eve flipped 1 bit at byte offset " + str(mid) + " of ciphertext in transit!")

    elif attack == "forge_signature":
        mallory = IdentityKeys.generate("Mallory (Attacker)")
        fake_sig = sign_bytes_rsa_pss(mallory.private_key, b"forged-payload")
        transmitted["digital_signature"]["signature_b64"] = base64.b64encode(fake_sig).decode("ascii")
        channel_notes.append(f"ATTACK INJECTED: Mallory replaced digital signature using rogue key (FP: {mallory.fingerprint()})!")

    elif attack == "wrong_chaotic_key":
        # Demonstrate hyper-sensitivity of Chaotic decryption to Delta x0 = +1e-14
        ch_enc = encrypt_image_chaotic(image, chaotic_params)
        perturbed_params = ChaoticParams(
            passphrase=chaotic_params.passphrase,
            x0=chaotic_params.x0 + 1e-14,
            r=chaotic_params.r,
            arnold_p=chaotic_params.arnold_p,
            arnold_q=chaotic_params.arnold_q,
            arnold_iters=chaotic_params.arnold_iters,
            diffusion_rounds=chaotic_params.diffusion_rounds,
        )
        wrong_dec, _ = decrypt_image_chaotic(ch_enc.cipher_image, perturbed_params)
        wrong_key_image = wrong_dec
        sensitivity_metrics = compute_npcr_uaci(image, wrong_dec)
        channel_notes.append(
            f"CHAOTIC KEY SENSITIVITY TEST: Attempted decryption with x0 + 1e-14 -> "
            f"Result is pure noise (NPCR vs Original = {sensitivity_metrics['npcr']}%, UACI = {sensitivity_metrics['uaci']}%)."
        )

    verification = verify_and_open_envelope(
        transmitted,
        receiver=bob,
        trusted_signer_pem=alice.public_pem(),
    )

    fidelity = None
    if verification["decrypted_image"] is not None:
        fidelity = compute_mse_psnr(image, verification["decrypted_image"])

    return {
        "scheme": scheme,
        "aes_mode": aes_mode if scheme == "AES" else None,
        "attack": attack,
        "vault_path": vault_path,
        "alice_fingerprint": alice.fingerprint(),
        "bob_fingerprint": bob.fingerprint(),
        "ciphertext_sha256": envelope["ciphertext_sha256"],
        "signature_b64_preview": envelope["digital_signature"]["signature_b64"][:48] + "...",
        "channel_notes": channel_notes,
        "verification": {
            "success": verification["success"],
            "signature_valid": verification["signature_valid"],
            "integrity_valid": verification["integrity_valid"],
            "stage_failed": verification["stage_failed"],
            "logs": verification["logs"],
            "elapsed_ms": verification["elapsed_ms"],
        },
        "fidelity": fidelity,
        "cipher_image": cipher_img,
        "decrypted_image": verification["decrypted_image"],
        "wrong_key_image": wrong_key_image,
        "sensitivity_metrics": sensitivity_metrics,
        "envelope": envelope,
    }
