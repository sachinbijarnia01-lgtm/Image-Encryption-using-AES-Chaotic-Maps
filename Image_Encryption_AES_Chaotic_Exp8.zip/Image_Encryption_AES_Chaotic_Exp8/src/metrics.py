"""Statistical & Cryptographic Security Metrics for Image Encryption.

Includes:
- Histogram Analysis (R, G, B & Luminance/Grayscale 256-bin histograms + Chi-Square uniformity test)
- Adjacent Pixel Correlation Analysis (Horizontal, Vertical, Diagonal coefficients + scatter pairs)
- Information Entropy Analysis (Global & Per-Channel Shannon Entropy in bits/byte)
- Differential Attack Resistance (NPCR & UACI)
- Reconstruction Fidelity (MSE & PSNR)
"""

from __future__ import annotations

from typing import Any
import numpy as np


def compute_shannon_entropy(data: np.ndarray) -> float:
    """Compute 8-bit Shannon Information Entropy H(X) = -sum p(x_i) log2 p(x_i). Ideal = 8.0."""
    counts = np.bincount(data.ravel(), minlength=256).astype(np.float64)
    total = counts.sum()
    if total == 0:
        return 0.0
    probs = counts[counts > 0] / total
    return float(-np.sum(probs * np.log2(probs)))


def compute_histograms(image: np.ndarray) -> dict[str, Any]:
    """Compute 256-bin histograms for R, G, B, and Grayscale intensity plus Chi-Square uniformity."""
    if image.ndim == 2:
        gray = image
        hist_gray = np.bincount(gray.ravel(), minlength=256).tolist()
        channels = {"Gray": hist_gray}
    else:
        r = np.bincount(image[:, :, 0].ravel(), minlength=256).tolist()
        g = np.bincount(image[:, :, 1].ravel(), minlength=256).tolist()
        b = np.bincount(image[:, :, 2].ravel(), minlength=256).tolist()
        gray_arr = np.round(
            0.299 * image[:, :, 0] + 0.587 * image[:, :, 1] + 0.114 * image[:, :, 2]
        ).astype(np.uint8)
        hist_gray = np.bincount(gray_arr.ravel(), minlength=256).tolist()
        channels = {"R": r, "G": g, "B": b, "Gray": hist_gray}

    # Chi-Square test against uniform 256-bin distribution across all raw bytes
    all_counts = np.bincount(image.ravel(), minlength=256).astype(np.float64)
    expected = image.size / 256.0
    chi_square = float(np.sum(((all_counts - expected) ** 2) / max(expected, 1e-9)))
    hist_variance = float(np.var(all_counts))

    return {
        "channels": channels,
        "chi_square": round(chi_square, 2),       # Critical alpha=0.05 (df=255) is ~293.25
        "is_uniform_95": bool(chi_square < 293.25),
        "bin_variance": round(hist_variance, 2),
    }


def _pearson_corr(x: np.ndarray, y: np.ndarray) -> float:
    x_f = x.astype(np.float64)
    y_f = y.astype(np.float64)
    sx = np.std(x_f)
    sy = np.std(y_f)
    if sx < 1e-12 or sy < 1e-12:
        return 0.0
    return float(np.mean((x_f - np.mean(x_f)) * (y_f - np.mean(y_f))) / (sx * sy))


def compute_adjacent_correlation(
    image: np.ndarray,
    sample_size: int = 2500,
    seed: int = 42,
) -> dict[str, Any]:
    """Compute Horizontal, Vertical, and Diagonal adjacent pixel correlations and scatter samples."""
    # Preserve exact per-channel [0, 255] marginal distributions (no cross-channel averaging)
    if image.ndim == 3:
        hx, hy = image[:, :-1, :].ravel(), image[:, 1:, :].ravel()
        vx, vy = image[:-1, :, :].ravel(), image[1:, :, :].ravel()
        dx, dy = image[:-1, :-1, :].ravel(), image[1:, 1:, :].ravel()
    else:
        hx, hy = image[:, :-1].ravel(), image[:, 1:].ravel()
        vx, vy = image[:-1, :].ravel(), image[1:, :].ravel()
        dx, dy = image[:-1, :-1].ravel(), image[1:, 1:].ravel()

    r_h = _pearson_corr(hx, hy)
    r_v = _pearson_corr(vx, vy)
    r_d = _pearson_corr(dx, dy)

    # Random subset for fast, clean scatter visualization
    rng = np.random.default_rng(seed)

    def _sample_pairs(a: np.ndarray, b: np.ndarray) -> dict[str, list[int]]:
        n = min(sample_size, len(a))
        idx = rng.choice(len(a), size=n, replace=False)
        return {"x": a[idx].astype(int).tolist(), "y": b[idx].astype(int).tolist()}

    return {
        "horizontal": round(r_h, 6),
        "vertical": round(r_v, 6),
        "diagonal": round(r_d, 6),
        "avg_abs": round((abs(r_h) + abs(r_v) + abs(r_d)) / 3.0, 6),
        "scatter": {
            "horizontal": _sample_pairs(hx, hy),
            "vertical": _sample_pairs(vx, vy),
            "diagonal": _sample_pairs(dx, dy),
        },
    }


def compute_entropy_breakdown(image: np.ndarray) -> dict[str, float]:
    """Compute global and per-channel Shannon entropy."""
    global_h = compute_shannon_entropy(image)
    if image.ndim == 3 and image.shape[2] >= 3:
        return {
            "global": round(global_h, 6),
            "R": round(compute_shannon_entropy(image[:, :, 0]), 6),
            "G": round(compute_shannon_entropy(image[:, :, 1]), 6),
            "B": round(compute_shannon_entropy(image[:, :, 2]), 6),
        }
    return {"global": round(global_h, 6)}


def compute_npcr_uaci(cipher1: np.ndarray, cipher2: np.ndarray) -> dict[str, float]:
    """Compute NPCR (ideal ~99.6094%) and UACI (ideal ~33.4635%) between two cipher images."""
    c1 = cipher1.astype(np.float64)
    c2 = cipher2.astype(np.float64)
    diff_mask = (cipher1 != cipher2)
    npcr = float(np.mean(diff_mask) * 100.0)
    uaci = float(np.mean(np.abs(c1 - c2) / 255.0) * 100.0)
    return {
        "npcr": round(npcr, 4),
        "uaci": round(uaci, 4),
    }


def compute_mse_psnr(img1: np.ndarray, img2: np.ndarray) -> dict[str, float | str]:
    """Compute Mean Squared Error (MSE) and Peak Signal-to-Noise Ratio (PSNR in dB)."""
    mse = float(np.mean((img1.astype(np.float64) - img2.astype(np.float64)) ** 2))
    if mse == 0.0:
        return {"mse": 0.0, "psnr": "Infinity"}
    psnr = 10.0 * np.log10((255.0 ** 2) / mse)
    return {"mse": round(mse, 4), "psnr": round(float(psnr), 4)}


def analyze_single_image(image: np.ndarray, sample_size: int = 1800) -> dict[str, Any]:
    """Run full histogram, correlation, and entropy analysis on a single image."""
    return {
        "entropy": compute_entropy_breakdown(image),
        "histogram": compute_histograms(image),
        "correlation": compute_adjacent_correlation(image, sample_size=sample_size),
    }
