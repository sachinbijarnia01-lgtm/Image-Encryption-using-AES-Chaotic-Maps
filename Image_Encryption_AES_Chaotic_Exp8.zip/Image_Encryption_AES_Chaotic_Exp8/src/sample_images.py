"""Generate standard test images for Image Encryption & Statistical Analysis."""

from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw


def create_natural_scene(size: int = 256) -> Image.Image:
    """Create a rich RGB landscape scene with sky gradient, sun, mountains, and water reflections."""
    y, x = np.mgrid[0:size, 0:size].astype(np.float64)
    ny = y / size
    nx = x / size

    # Sky gradient
    r = np.clip(35 + 195 * (1.0 - np.abs(ny - 0.48) * 1.6), 20, 245)
    g = np.clip(65 + 140 * (1.0 - ny * 0.9), 30, 230)
    b = np.clip(150 + 95 * (1.0 - ny), 50, 250)

    # Sun disc
    dist_sun = np.sqrt((nx - 0.72) ** 2 + (ny - 0.26) ** 2)
    sun_glow = np.exp(-dist_sun * 10.0)
    r = np.clip(r + 120 * sun_glow, 0, 255)
    g = np.clip(g + 95 * sun_glow, 0, 255)
    b = np.clip(b + 35 * sun_glow, 0, 255)
    sun_core = dist_sun < 0.085
    r[sun_core], g[sun_core], b[sun_core] = 255, 242, 185

    # Layered mountain ridges
    ridge1 = 0.50 + 0.09 * np.sin(nx * 7.5 + 0.4) + 0.04 * np.cos(nx * 19.0)
    ridge2 = 0.60 + 0.07 * np.sin(nx * 11.0 + 2.1) + 0.03 * np.sin(nx * 27.0)

    m1 = ny > ridge1
    r[m1] = 58 + 25 * (ny[m1] - 0.5)
    g[m1] = 74 + 35 * (ny[m1] - 0.5)
    b[m1] = 108 + 20 * (ny[m1] - 0.5)

    m2 = ny > ridge2
    r[m2] = 34 + 30 * np.sin(nx[m2] * 12)
    g[m2] = 92 + 25 * np.cos(nx[m2] * 9)
    b[m2] = 68

    # Lake reflection at bottom
    lake = ny > 0.72
    ripple = 0.5 + 0.5 * np.sin(ny * 95.0 + nx * 18.0)
    r[lake] = np.clip(45 + 115 * ripple[lake] * np.exp(-np.abs(nx[lake] - 0.72) * 5.0), 20, 240)
    g[lake] = np.clip(85 + 85 * ripple[lake] * np.exp(-np.abs(nx[lake] - 0.72) * 5.0), 40, 220)
    b[lake] = np.clip(135 + 45 * ripple[lake], 80, 225)

    arr = np.stack([r, g, b], axis=-1).astype(np.uint8)
    return Image.fromarray(arr, mode="RGB")


def create_security_badge(size: int = 256) -> Image.Image:
    """Create a structured emblem image with flat regions (ideal for demonstrating AES-ECB leakage vs CBC/Chaotic)."""
    img = Image.new("RGB", (size, size), (18, 28, 48))
    draw = ImageDraw.Draw(img)

    # Outer border & grid blocks
    pad = 16
    draw.rectangle([pad, pad, size - pad, size - pad], outline=(64, 196, 255), width=4)
    draw.rectangle([pad + 10, pad + 10, size - pad - 10, size - pad - 10], fill=(28, 44, 76))

    # Shield polygon
    cx = size // 2
    shield = [
        (cx, 42),
        (size - 56, 68),
        (size - 64, 148),
        (cx, size - 40),
        (64, 148),
        (56, 68),
    ]
    draw.polygon(shield, fill=(235, 178, 44), outline=(255, 236, 153))

    inner_shield = [
        (cx, 58),
        (size - 72, 79),
        (size - 78, 142),
        (cx, size - 58),
        (78, 142),
        (72, 79),
    ]
    draw.polygon(inner_shield, fill=(18, 86, 136))

    # Padlock icon inside shield
    draw.arc([cx - 24, 82, cx + 24, 132], start=180, end=0, fill=(255, 255, 255), width=7)
    draw.rectangle([cx - 32, 112, cx + 32, 164], fill=(244, 247, 252), outline=(35, 55, 85), width=2)
    draw.ellipse([cx - 8, 126, cx + 8, 142], fill=(210, 50, 65))
    draw.polygon([(cx - 4, 138), (cx + 4, 138), (cx + 7, 154), (cx - 7, 154)], fill=(210, 50, 65))

    # Corner calibration squares
    for (ox, oy, col) in [
        (34, 34, (239, 68, 68)),
        (size - 58, 34, (34, 197, 94)),
        (34, size - 58, (59, 130, 246)),
        (size - 58, size - 58, (168, 85, 247)),
    ]:
        draw.rectangle([ox, oy, ox + 24, oy + 24], fill=col)

    return img


def create_medical_phantom(size: int = 256) -> Image.Image:
    """Create a Shepp-Logan-inspired medical brain MRI phantom (RGB grayscale-tinted)."""
    y, x = np.mgrid[-1:1:complex(0, size), -1:1:complex(0, size)]
    canvas = np.zeros((size, size), dtype=np.float64)

    ellipses = [
        # (intensity, a, b, x0, y0, phi_deg)
        (0.85, 0.69, 0.92, 0.0, 0.0, 0),
        (-0.55, 0.6624, 0.874, 0.0, -0.0184, 0),
        (-0.22, 0.11, 0.31, 0.22, 0.0, -18),
        (-0.22, 0.16, 0.41, -0.22, 0.0, 18),
        (0.35, 0.21, 0.25, 0.0, 0.35, 0),
        (0.30, 0.046, 0.046, 0.0, 0.1, 0),
        (0.30, 0.046, 0.046, 0.0, -0.1, 0),
        (0.35, 0.046, 0.023, -0.08, -0.605, 0),
        (0.35, 0.023, 0.023, 0.0, -0.606, 0),
        (0.35, 0.023, 0.046, 0.06, -0.605, 0),
    ]

    for val, a, b, x0, y0, phi in ellipses:
        th = np.deg2rad(phi)
        xr = (x - x0) * np.cos(th) + (y - y0) * np.sin(th)
        yr = -(x - x0) * np.sin(th) + (y - y0) * np.cos(th)
        mask = (xr / a) ** 2 + (yr / b) ** 2 <= 1.0
        canvas[mask] += val

    # Smooth tissue gradient inside skull
    radial = np.exp(-((x ** 2 + y ** 2) * 1.8))
    canvas = np.clip(canvas * (0.82 + 0.25 * radial), 0.0, 1.0)
    gray = (canvas * 255).astype(np.uint8)
    arr = np.stack([gray, gray, np.clip(gray * 1.04, 0, 255).astype(np.uint8)], axis=-1)
    return Image.fromarray(arr, mode="RGB")


def create_fractal_color(size: int = 256) -> Image.Image:
    """Create a colorful Julia set texture with intricate multi-scale detail."""
    y, x = np.mgrid[-1.35:1.35:complex(0, size), -1.35:1.35:complex(0, size)]
    z = x + 1j * y
    c = complex(-0.7269, 0.1889)
    iters = np.zeros(z.shape, dtype=np.float64)
    mask = np.ones(z.shape, dtype=bool)

    max_iter = 64
    for i in range(max_iter):
        z[mask] = z[mask] * z[mask] + c
        diverged = mask & (np.abs(z) > 4.0)
        iters[diverged] = i + 1 - np.log2(np.maximum(np.log2(np.abs(z[diverged])), 1.0))
        mask &= ~diverged

    iters[mask] = max_iter
    norm = iters / max_iter
    r = (0.5 + 0.5 * np.cos(3.0 + norm * 12.0 + 0.0)) * 255
    g = (0.5 + 0.5 * np.cos(3.0 + norm * 12.0 + 2.1)) * 255
    b = (0.5 + 0.5 * np.cos(3.0 + norm * 12.0 + 4.2)) * 255
    arr = np.stack([r, g, b], axis=-1).astype(np.uint8)
    return Image.fromarray(arr, mode="RGB")


def ensure_sample_images(samples_dir: str | Path = "samples") -> dict[str, str]:
    """Generate and save all default sample images if not present."""
    out_dir = Path(samples_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    generators = {
        "natural_scene": ("Natural Landscape (RGB)", create_natural_scene),
        "security_badge": ("Security Emblem (Structured / ECB Test)", create_security_badge),
        "medical_phantom": ("Medical Brain MRI Phantom", create_medical_phantom),
        "fractal_color": ("Julia Fractal (High Texture)", create_fractal_color),
    }

    paths = {}
    for key, (_label, fn) in generators.items():
        file_path = out_dir / f"{key}.png"
        if not file_path.exists():
            img = fn(256)
            img.save(file_path, format="PNG")
        paths[key] = str(file_path)
    return paths
