"""Comprehensive Unit & Integration Tests for Experiment 8 Mini Project."""

from __future__ import annotations

import unittest
import numpy as np

from app import app
from src.aes_cipher import decrypt_image_aes, encrypt_image_aes
from src.chaotic_cipher import ChaoticParams, decrypt_image_chaotic, encrypt_image_chaotic
from src.exp8_protocol import simulate_exp8_transmission
from src.metrics import (
    compute_adjacent_correlation,
    compute_histograms,
    compute_npcr_uaci,
    compute_shannon_entropy,
)


class TestImageEncryptionExp8(unittest.TestCase):
    def setUp(self) -> None:
        rng = np.random.default_rng(123)
        # Create structured gradient image with strong spatial correlation
        y, x = np.mgrid[0:128, 0:128]
        self.square_rgb = np.stack(
            [(x * 2) & 0xFF, (y * 2) & 0xFF, ((x + y)) & 0xFF],
            axis=-1,
        ).astype(np.uint8)
        # Non-square rectangular image
        self.rect_rgb = self.square_rgb[:96, :120, :].copy()
        # Grayscale 2D image
        self.gray_2d = self.square_rgb[:, :, 0].copy()

    def test_aes_all_modes_lossless(self) -> None:
        for mode in ("GCM", "CBC", "CTR", "ECB"):
            for img in (self.square_rgb, self.rect_rgb, self.gray_2d):
                enc = encrypt_image_aes(img, passphrase="test-password", mode=mode)  # type: ignore[arg-type]
                dec, _ = decrypt_image_aes(enc, passphrase="test-password")
                self.assertEqual(img.shape, enc.cipher_image.shape)
                np.testing.assert_array_equal(img, dec, err_msg=f"AES-{mode} failed lossless check")

    def test_chaotic_lossless_all_shapes(self) -> None:
        params = ChaoticParams(passphrase="chaos-test", x0=0.371829304123, r=3.997654321)
        for img in (self.square_rgb, self.rect_rgb, self.gray_2d):
            enc = encrypt_image_chaotic(img, params)
            dec, _ = decrypt_image_chaotic(enc.cipher_image, params)
            self.assertEqual(img.shape, enc.cipher_image.shape)
            np.testing.assert_array_equal(img, dec, err_msg="Chaotic cipher failed lossless check")

    def test_entropy_histogram_and_correlation_strength(self) -> None:
        aes_cipher = encrypt_image_aes(self.square_rgb, mode="CBC").cipher_image
        ch_cipher = encrypt_image_chaotic(self.square_rgb, ChaoticParams()).cipher_image

        for name, c_img in (("AES-CBC", aes_cipher), ("Chaotic", ch_cipher)):
            h = compute_shannon_entropy(c_img)
            self.assertGreater(h, 7.99, f"{name} entropy too low: {h}")

            hist = compute_histograms(c_img)
            self.assertLess(hist["chi_square"], 330.0, f"{name} chi-square too high: {hist['chi_square']}")

            corr = compute_adjacent_correlation(c_img)
            self.assertLess(abs(corr["horizontal"]), 0.03, f"{name} r_H too high")
            self.assertLess(abs(corr["vertical"]), 0.03, f"{name} r_V too high")
            self.assertLess(abs(corr["diagonal"]), 0.03, f"{name} r_D too high")

    def test_chaotic_key_hypersensitivity_and_differential_npcr(self) -> None:
        p1 = ChaoticParams(x0=0.41728394015263)
        p2 = ChaoticParams(x0=0.41728394015263 + 1e-14)
        enc1 = encrypt_image_chaotic(self.square_rgb, p1)
        enc1_perturbed_key = encrypt_image_chaotic(self.square_rgb, p2)

        # Ciphertext key sensitivity (C1 vs C2 under 10^-14 key shift -> UACI ~ 33.46%, NPCR ~ 99.61%)
        key_sens = compute_npcr_uaci(enc1.cipher_image, enc1_perturbed_key.cipher_image)
        self.assertGreater(key_sens["npcr"], 99.4)
        self.assertGreater(key_sens["uaci"], 33.0)

        # Decryption key sensitivity (decrypting with x0 + 10^-14 yields uniform noise)
        wrong_dec, _ = decrypt_image_chaotic(enc1.cipher_image, p2)
        diff_dec = compute_npcr_uaci(self.square_rgb, wrong_dec)
        self.assertGreater(diff_dec["npcr"], 99.3)
        self.assertGreater(compute_shannon_entropy(wrong_dec), 7.99)

        # Plaintext 1-LSB differential test
        mod_img = self.square_rgb.copy()
        mod_img[64, 64, 1] ^= 1
        enc2 = encrypt_image_chaotic(mod_img, p1)
        diff_pt = compute_npcr_uaci(enc1.cipher_image, enc2.cipher_image)
        self.assertGreater(diff_pt["npcr"], 99.4)
        self.assertGreater(diff_pt["uaci"], 33.0)

    def test_exp8_signatures_and_attacks(self) -> None:
        clean = simulate_exp8_transmission(self.square_rgb, scheme="AES", aes_mode="GCM", attack="none")
        self.assertTrue(clean["verification"]["success"])
        np.testing.assert_array_equal(self.square_rgb, clean["decrypted_image"])

        tamper = simulate_exp8_transmission(self.square_rgb, scheme="AES", aes_mode="GCM", attack="tamper_ciphertext")
        self.assertFalse(tamper["verification"]["success"])
        self.assertEqual(tamper["verification"]["stage_failed"], "digital_signature")

        forged = simulate_exp8_transmission(self.square_rgb, scheme="CHAOTIC", attack="forge_signature")
        self.assertFalse(forged["verification"]["success"])
        self.assertEqual(forged["verification"]["stage_failed"], "digital_signature")

    def test_flask_web_endpoints(self) -> None:
        client = app.test_client()
        r_home = client.get("/")
        self.assertEqual(r_home.status_code, 200)

        r_comp = client.post("/api/compare", json={"sample": "security_badge", "aes_mode": "CBC"})
        self.assertEqual(r_comp.status_code, 200)
        body = r_comp.get_json()
        self.assertTrue(body["ok"])
        self.assertEqual(body["data"]["metrics"]["aes"]["decryption_fidelity"]["mse"], 0.0)
        self.assertEqual(body["data"]["metrics"]["chaotic"]["decryption_fidelity"]["mse"], 0.0)

        r_exp8 = client.post("/api/exp8", json={"sample": "natural_scene", "scheme": "CHAOTIC", "attack": "wrong_chaotic_key"})
        self.assertEqual(r_exp8.status_code, 200)
        e_body = r_exp8.get_json()
        self.assertTrue(e_body["ok"])
        self.assertTrue(e_body["data"]["verification"]["success"])
        self.assertGreater(e_body["data"]["sensitivity_metrics"]["npcr"], 99.4)


if __name__ == "__main__":
    unittest.main()
